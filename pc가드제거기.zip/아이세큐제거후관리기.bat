@echo off
title iSecuService
takeown /f "C:\Program Files\iSecuService\iSecuService.exe" >nul 2>&1
icacls "C:\Program Files\iSecuService\iSecuService.exe" /deny everyone:RX >nul 2>&1
:loop
taskkill /f /im iSecuService.exe >nul 2>&1
timeout /t 0 /nobreak >nul
goto loop