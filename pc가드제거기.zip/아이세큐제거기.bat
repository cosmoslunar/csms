@echo off
chcp 65001 >nul
title iSecuService제거기

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo 관리자 권한 필요
    pause
    exit
)
echo iSecuService 제거 시작
timeout /t 1 >nul
taskkill /f /im iSecuService.exe >nul 2>&1
sc stop iSecuService >nul 2>&1
sc delete iSecuService >nul 2>&1
taskkill /f /im iSecuService.exe >nul 2>&1
sc stop iSecuService >nul 2>&1
sc delete iSecuService >nul 2>&1
taskkill /f /im iSecuService.exe >nul 2>&1
sc stop iSecuService >nul 2>&1
sc delete iSecuService >nul 2>&1
schtasks /delete /tn "iSecuService" /f >nul 2>&1
reg delete HKLM\Software\Microsoft\Windows\CurrentVersion\Run /v iSecuService /f >nul 2>&1
reg delete HKCU\Software\Microsoft\Windows\CurrentVersion\Run /v iSecuService /f >nul 2>&1
schtasks /delete /tn "iSecuService" /f >nul 2>&1
reg delete HKLM\Software\Microsoft\Windows\CurrentVersion\Run /v iSecuService /f >nul 2>&1
reg delete HKCU\Software\Microsoft\Windows\CurrentVersion\Run /v iSecuService /f >nul 2>&1
schtasks /delete /tn "iSecuService" /f >nul 2>&1
reg delete HKLM\Software\Microsoft\Windows\CurrentVersion\Run /v iSecuService /f >nul 2>&1
reg delete HKCU\Software\Microsoft\Windows\CurrentVersion\Run /v iSecuService /f >nul 2>&1
takeown /f "C:\Program Files\iSecuService" /r /d y >nul 2>&1
icacls "C:\Program Files\iSecuService" /grant administrators:F /t >nul 2>&1
rd /s /q "C:\Program Files\iSecuService" >nul 2>&1
mkdir "C:\Program Files\iSecuService" >nul 2>&1
icacls "C:\Program Files\iSecuService" /inheritance:r >nul 2>&1
icacls "C:\Program Files\iSecuService" /deny everyone:(OI)(CI)F >nul 2>&1

echo 완료됨 재부팅 필요
pause